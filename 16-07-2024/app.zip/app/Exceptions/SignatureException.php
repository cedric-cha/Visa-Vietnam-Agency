<?php

namespace App\Exceptions;

use Exception;

class SignatureException extends Exception
{
    //
}
